Option Explicit

Const ForReading = 1
Const StartupTimeoutSeconds = 60

Dim fso, shell, processEnvironment
Dim rootDir, dataDir, runtimePython
Dim stateFile, lockDir, stdoutFile, stderrFile
Dim readyUrl, command, startedAt, returnCode

Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")
Set processEnvironment = shell.Environment("PROCESS")

rootDir = fso.GetParentFolderName(WScript.ScriptFullName)
runtimePython = fso.BuildPath(fso.BuildPath(rootDir, "runtime"), "pythonw.exe")

If Trim(processEnvironment("FAMILY_TREE_DATA_DIR")) = "" Then
    dataDir = fso.BuildPath(rootDir, "data")
Else
    dataDir = fso.GetAbsolutePathName(processEnvironment("FAMILY_TREE_DATA_DIR"))
End If

On Error Resume Next
EnsureFolder dataDir
If Err.Number <> 0 Then
    ShowError U("41D 435 20 443 434 430 43B 43E 441 44C 20 43F 43E 434 433 43E 442 43E 432 438 442 44C 20 43F 430 43F 43A 443 20 434 430 43D 43D 44B 445 3A") & vbCrLf & dataDir
    WScript.Quit 1
End If
On Error GoTo 0

stateFile = fso.BuildPath(dataDir, "family-tree.url")
lockDir = fso.BuildPath(dataDir, "family-tree-launching")
stdoutFile = fso.BuildPath(dataDir, "launcher.stdout.log")
stderrFile = fso.BuildPath(dataDir, "launcher-error.log")

readyUrl = ReadReadyUrl(stateFile)
If readyUrl <> "" Then
    If IsHealthy(readyUrl) Then
        OpenBrowser readyUrl
        WScript.Quit 0
    End If
    DeleteFileIfExists stateFile
End If

If fso.FolderExists(lockDir) Then
    If DateDiff("s", fso.GetFolder(lockDir).DateLastModified, Now) > StartupTimeoutSeconds Then
        On Error Resume Next
        fso.DeleteFolder lockDir, True
        On Error GoTo 0
    End If
End If

If Not TryAcquireLock(lockDir) Then
    readyUrl = WaitForExistingStartup(stateFile)
    If readyUrl <> "" Then
        OpenBrowser readyUrl
        WScript.Quit 0
    End If
    ShowError U("41F 440 43E 433 440 430 43C 43C 430 20 443 436 435 20 437 430 43F 443 441 43A 430 435 442 441 44F 2C 20 43D 43E 20 43D 435 20 43E 442 432 435 442 438 43B 430 20 432 43E 432 440 435 43C 44F 2E") & vbCrLf & vbCrLf & U("41F 43E 434 43E 436 434 438 442 435 20 43D 435 43C 43D 43E 433 43E 20 438 20 43F 43E 43F 440 43E 431 443 439 442 435 20 435 449 451 20 440 430 437 2E")
    WScript.Quit 1
End If

If Not fso.FileExists(runtimePython) Then
    ReleaseLock lockDir
    ShowError U("41D 435 20 443 434 430 43B 43E 441 44C 20 437 430 43F 443 441 442 438 442 44C 20 43F 440 43E 433 440 430 43C 43C 443 2E") & vbCrLf & vbCrLf & U("41F 440 43E 432 435 440 44C 442 435 2C 20 447 442 43E 20 43F 430 43F 43A 430 20 43F 440 43E 433 440 430 43C 43C 44B 20 441 43A 43E 43F 438 440 43E 432 430 43D 430 20 43F 43E 43B 43D 43E 441 442 44C 44E 2E")
    WScript.Quit 1
End If

DeleteFileIfExists stdoutFile
DeleteFileIfExists stderrFile
processEnvironment("PYTHONUNBUFFERED") = "1"
shell.CurrentDirectory = rootDir
command = Quote(processEnvironment("ComSpec")) & " /d /s /c " & Quote(Quote(runtimePython) & " -u -m app 1>" & Quote(stdoutFile) & " 2>" & Quote(stderrFile))

On Error Resume Next
returnCode = shell.Run(command, 0, False)
If Err.Number <> 0 Then
    On Error GoTo 0
    ReleaseLock lockDir
    ShowError U("41D 435 20 443 434 430 43B 43E 441 44C 20 437 430 43F 443 441 442 438 442 44C 20 43F 440 43E 433 440 430 43C 43C 443 2E") & vbCrLf & vbCrLf & U("41F 440 43E 432 435 440 44C 442 435 2C 20 447 442 43E 20 43F 430 43F 43A 430 20 43F 440 43E 433 440 430 43C 43C 44B 20 441 43A 43E 43F 438 440 43E 432 430 43D 430 20 43F 43E 43B 43D 43E 441 442 44C 44E 2E")
    WScript.Quit 1
End If
On Error GoTo 0

startedAt = Now
Do While DateDiff("s", startedAt, Now) <= StartupTimeoutSeconds
    readyUrl = FindReadyUrl(stdoutFile)
    If readyUrl <> "" Then
        WriteReadyUrl stateFile, readyUrl
        ReleaseLock lockDir
        OpenBrowser readyUrl
        WScript.Quit 0
    End If
    WScript.Sleep 250
Loop

ReleaseLock lockDir
ShowError U("41F 440 43E 433 440 430 43C 43C 430 20 43D 435 20 437 430 43F 443 441 442 438 43B 430 441 44C 20 437 430 20 36 30 20 441 435 43A 443 43D 434 2E") & vbCrLf & vbCrLf & U("41F 43E 43F 440 43E 431 443 439 442 435 20 435 449 451 20 440 430 437 2E 20 415 441 43B 438 20 43E 448 438 431 43A 430 20 43F 43E 432 442 43E 440 438 442 441 44F 2C 20 43F 435 440 435 434 430 439 442 435 20 441 43F 435 446 438 430 43B 438 441 442 443 20 444 430 439 43B 3A") & vbCrLf & stderrFile
WScript.Quit 1

Function U(codes)
    Dim parts, item, result
    parts = Split(codes, " ")
    result = ""
    For Each item In parts
        result = result & ChrW(CLng("&H" & item))
    Next
    U = result
End Function

Function Quote(value)
    Quote = Chr(34) & value & Chr(34)
End Function

Sub ShowError(message)
    MsgBox message, vbOKOnly + vbExclamation, U("421 435 43C 435 439 43D 43E 435 20 434 435 440 435 432 43E")
End Sub

Sub EnsureFolder(path)
    Dim parent
    If fso.FolderExists(path) Then Exit Sub
    parent = fso.GetParentFolderName(path)
    If parent <> "" And Not fso.FolderExists(parent) Then EnsureFolder parent
    fso.CreateFolder path
End Sub

Sub DeleteFileIfExists(path)
    On Error Resume Next
    If fso.FileExists(path) Then fso.DeleteFile path, True
    On Error GoTo 0
End Sub

Function TryAcquireLock(path)
    On Error Resume Next
    fso.CreateFolder path
    TryAcquireLock = (Err.Number = 0)
    Err.Clear
    On Error GoTo 0
End Function

Sub ReleaseLock(path)
    On Error Resume Next
    If fso.FolderExists(path) Then fso.DeleteFolder path, True
    On Error GoTo 0
End Sub

Function ReadAll(path)
    Dim stream
    ReadAll = ""
    If Not fso.FileExists(path) Then Exit Function
    On Error Resume Next
    Set stream = fso.OpenTextFile(path, ForReading, False)
    If Err.Number = 0 Then
        ReadAll = stream.ReadAll
        stream.Close
    End If
    Err.Clear
    On Error GoTo 0
End Function

Function ValidUrl(candidate)
    Dim prefix, portText, portNumber, tail
    ValidUrl = False
    prefix = "http://127.0.0.1:"
    If Left(candidate, Len(prefix)) <> prefix Then Exit Function
    tail = Mid(candidate, Len(prefix) + 1)
    If Right(tail, 1) <> "/" Then Exit Function
    portText = Left(tail, Len(tail) - 1)
    If portText = "" Or Not IsNumeric(portText) Then Exit Function
    On Error Resume Next
    portNumber = CInt(portText)
    If Err.Number = 0 Then
        ValidUrl = (portNumber >= 8765 And portNumber <= 8815)
    End If
    Err.Clear
    On Error GoTo 0
End Function

Function ReadReadyUrl(path)
    Dim candidate
    candidate = Trim(ReadAll(path))
    If ValidUrl(candidate) Then
        ReadReadyUrl = candidate
    Else
        ReadReadyUrl = ""
    End If
End Function

Function FindReadyUrl(path)
    Dim content, marker, position, candidate, lineEnd
    FindReadyUrl = ""
    content = ReadAll(path)
    marker = "FAMILY_TREE_READY "
    position = InStrRev(content, marker)
    If position = 0 Then Exit Function
    candidate = Mid(content, position + Len(marker))
    lineEnd = InStr(candidate, vbCr)
    If lineEnd > 0 Then candidate = Left(candidate, lineEnd - 1)
    lineEnd = InStr(candidate, vbLf)
    If lineEnd > 0 Then candidate = Left(candidate, lineEnd - 1)
    candidate = Trim(candidate)
    If ValidUrl(candidate) Then FindReadyUrl = candidate
End Function

Sub WriteReadyUrl(path, url)
    Dim temporary, stream
    temporary = path & ".tmp"
    DeleteFileIfExists temporary
    Set stream = fso.CreateTextFile(temporary, True, False)
    stream.WriteLine url
    stream.Close
    DeleteFileIfExists path
    fso.MoveFile temporary, path
End Sub

Function IsHealthy(url)
    Dim request
    IsHealthy = False
    On Error Resume Next
    Set request = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    request.setTimeouts 1000, 1000, 1000, 1000
    request.open "GET", url, False
    request.send
    If Err.Number = 0 Then
        IsHealthy = (request.status >= 200 And request.status < 500)
    End If
    Err.Clear
    On Error GoTo 0
End Function

Function WaitForExistingStartup(path)
    Dim started, candidate
    WaitForExistingStartup = ""
    started = Now
    Do While DateDiff("s", started, Now) <= StartupTimeoutSeconds
        candidate = ReadReadyUrl(path)
        If candidate <> "" Then
            If IsHealthy(candidate) Then
                WaitForExistingStartup = candidate
                Exit Function
            End If
        End If
        WScript.Sleep 250
    Loop
End Function

Sub OpenBrowser(url)
    On Error Resume Next
    shell.Run url, 1, False
    If Err.Number <> 0 Then
        Err.Clear
        On Error GoTo 0
        ShowError U("41D 435 20 443 434 430 43B 43E 441 44C 20 43E 442 43A 440 44B 442 44C 20 431 440 430 443 437 435 440 2E") & vbCrLf & vbCrLf & U("41E 442 43A 440 43E 439 442 435 20 44D 442 43E 442 20 430 434 440 435 441 20 432 440 443 447 43D 443 44E 3A") & vbCrLf & url
        Exit Sub
    End If
    On Error GoTo 0
End Sub
