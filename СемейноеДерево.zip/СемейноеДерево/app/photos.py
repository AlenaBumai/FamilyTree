"""Проверка и локальное хранение фотографий персон."""

from __future__ import annotations

import io
import os
from dataclasses import dataclass
from pathlib import Path

from PIL import Image

from app.paths import DataPaths


MAX_PHOTO_BYTES = 10 * 1024 * 1024
THUMBNAIL_SIZE = 320
THUMBNAIL_QUALITY = 85
JPEG_EXTENSIONS = {".jpg", ".jpeg"}


class PhotoValidationError(ValueError):
    """Загруженный файл не удовлетворяет требованиям к фотографии."""


class UnsafePhotoPathError(ValueError):
    """Путь к фотографии выходит за разрешённые каталоги."""


@dataclass(frozen=True)
class PhotoSaveResult:
    relative_path: str
    thumbnail_created: bool
    thumbnail_error: str | None = None


def validate_jpeg(filename: str, content: bytes) -> None:
    """Проверить расширение, размер и фактический формат изображения."""

    if Path(filename).suffix.lower() not in JPEG_EXTENSIONS:
        raise PhotoValidationError("Разрешены только файлы JPG и JPEG")
    if len(content) > MAX_PHOTO_BYTES:
        raise PhotoValidationError("Размер фотографии не должен превышать 10 МБ")
    if not content:
        raise PhotoValidationError("Файл фотографии пуст")
    try:
        with Image.open(io.BytesIO(content)) as image:
            detected_format = image.format
            image.verify()
    except (OSError, SyntaxError, ValueError) as error:
        raise PhotoValidationError("Файл не является корректным JPEG-изображением") from error
    if detected_format != "JPEG":
        raise PhotoValidationError("Файл не является JPEG-изображением")


def generate_thumbnail(content: bytes, destination: Path) -> None:
    """Создать JPEG-миниатюру, не меняя оригинальные байты."""

    with Image.open(io.BytesIO(content)) as image:
        image.thumbnail((THUMBNAIL_SIZE, THUMBNAIL_SIZE))
        if image.mode != "RGB":
            image = image.convert("RGB")
        image.save(destination, format="JPEG", quality=THUMBNAIL_QUALITY)


def save_photo(
    paths: DataPaths,
    person_id: int,
    filename: str,
    content: bytes,
) -> PhotoSaveResult:
    """Сохранить оригинал и отдельно попытаться создать миниатюру."""

    if isinstance(person_id, bool) or not isinstance(person_id, int) or person_id <= 0:
        raise ValueError("Идентификатор персоны должен быть положительным целым числом")
    validate_jpeg(filename, content)
    paths.create()

    original = paths.photos / f"{person_id}.jpg"
    original_temporary = paths.photos / f".{person_id}.original.tmp"
    original_temporary.write_bytes(content)
    os.replace(original_temporary, original)

    thumbnail = paths.thumbs / f"{person_id}.jpg"
    thumbnail_temporary = paths.thumbs / f".{person_id}.thumbnail.tmp"
    try:
        generate_thumbnail(content, thumbnail_temporary)
        os.replace(thumbnail_temporary, thumbnail)
    except Exception as error:
        thumbnail_temporary.unlink(missing_ok=True)
        thumbnail.unlink(missing_ok=True)
        return PhotoSaveResult(
            relative_path=f"photos/{person_id}.jpg",
            thumbnail_created=False,
            thumbnail_error=str(error),
        )
    return PhotoSaveResult(
        relative_path=f"photos/{person_id}.jpg",
        thumbnail_created=True,
    )


def resolve_photo_path(
    paths: DataPaths,
    relative_path: str,
    *,
    must_exist: bool = True,
) -> Path:
    """Безопасно разрешить путь только внутри photos/ или thumbs/."""

    if not relative_path or Path(relative_path).is_absolute():
        raise UnsafePhotoPathError("Недопустимый путь к фотографии")
    candidate = (paths.root / relative_path).resolve()
    allowed_roots = (paths.photos.resolve(), paths.thumbs.resolve())
    if not any(candidate.is_relative_to(root) for root in allowed_roots):
        raise UnsafePhotoPathError("Недопустимый путь к фотографии")
    if must_exist and not candidate.is_file():
        raise FileNotFoundError(candidate)
    return candidate

