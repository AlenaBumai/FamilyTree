"""Выгрузка читаемых таблиц семейного архива в CSV для Excel и Access."""

from __future__ import annotations

import csv
import io
from collections.abc import Iterable, Mapping, Sequence
from typing import Any

from app.repo import PERSON_INPUT_FIELDS, PersonRepository
from app.textutil import normalize_gender


PERSON_EXPORT_FIELDS = ("id_person",) + PERSON_INPUT_FIELDS
RELATIONSHIP_EXPORT_FIELDS = (
    "id",
    "id_parent",
    "id_child",
    "parent_role",
    "relation_type",
)
PEOPLE_FILENAME = "семейное_дерево_персоны.csv"
RELATIONSHIPS_FILENAME = "семейное_дерево_связи.csv"


def _csv_bytes(headers: Sequence[str], rows: Iterable[Sequence[Any]]) -> bytes:
    output = io.StringIO(newline="")
    writer = csv.writer(output, delimiter=";", lineterminator="\r\n")
    writer.writerow(headers)
    writer.writerows(rows)
    return output.getvalue().encode("utf-8-sig")


def _person_value(person: Mapping[str, Any], field: str) -> Any:
    value = person.get(field)
    if field in {
        "main_lane",
        "birth_date_is_estimated",
        "death_date_is_estimated",
    }:
        return "да" if value == 1 else "нет"
    if field == "gender":
        return normalize_gender(value) or ""
    return "" if value is None else value


def export_people_csv(repository: PersonRepository) -> bytes:
    """Выгрузить основные поля персон без технических поисковых колонок."""

    rows = (
        tuple(_person_value(person, field) for field in PERSON_EXPORT_FIELDS)
        for person in repository.list_people()
    )
    return _csv_bytes(PERSON_EXPORT_FIELDS, rows)


def export_relationships_csv(repository: PersonRepository) -> bytes:
    """Выгрузить таблицу родительских связей."""

    rows = (
        tuple(
            "" if relationship[field] is None else relationship[field]
            for field in RELATIONSHIP_EXPORT_FIELDS
        )
        for relationship in repository.list_relationships()
    )
    return _csv_bytes(RELATIONSHIP_EXPORT_FIELDS, rows)
