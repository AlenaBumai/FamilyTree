"""Нормализация, сортировка и русские словоформы."""

from __future__ import annotations

from collections.abc import Callable


CYRILLIC_ALPHABET = "абвгдежзиійклмнопрстуўфхцчшщъыьэюя"
_LETTER_ORDER = {letter: index for index, letter in enumerate(CYRILLIC_ALPHABET)}


def norm(value: str | None) -> str:
    """Нормализовать текст для кириллического поиска и сортировки."""

    if value is None:
        return ""
    return " ".join(value.strip().split()).lower().replace("ё", "е")


def cyrillic_sort_key(value: str | None) -> tuple[tuple[int, int], ...]:
    """Построить ключ по объединённому русско-белорусскому алфавиту."""

    normalized = norm(value)
    return tuple(
        (0, _LETTER_ORDER[character])
        if character in _LETTER_ORDER
        else (1, ord(character))
        for character in normalized
    )


def cyrillic_compare(left: str | None, right: str | None) -> int:
    """Сравнить две строки; функция подходит для sqlite create_collation."""

    left_key = cyrillic_sort_key(left)
    right_key = cyrillic_sort_key(right)
    return (left_key > right_key) - (left_key < right_key)


def year_word(years: int) -> str:
    """Выбрать правильную форму слова «год» для целого числа."""

    absolute = abs(years)
    last_two = absolute % 100
    if 11 <= last_two <= 14:
        return "лет"
    last = absolute % 10
    if last == 1:
        return "год"
    if 2 <= last <= 4:
        return "года"
    return "лет"


def format_year_count(years: int) -> str:
    """Отформатировать число лет с правильной словоформой."""

    return f"{years} {year_word(years)}"


def normalize_gender(value: object) -> str | None:
    """Привести пол к читаемому канону «М»/«Ж» или вернуть None."""

    if not isinstance(value, str):
        return None
    normalized = value.strip().upper()
    return normalized if normalized in ("М", "Ж") else None


def lived_verb(gender: str | None) -> str | None:
    """Согласовать глагол с полом или вернуть нейтральную формулировку."""

    normalized = normalize_gender(gender)
    if normalized == "М":
        return "прожил"
    if normalized == "Ж":
        return "прожила"
    return None


# Короткий псевдоним удобен при передаче ключа напрямую в sorted().
sort_key: Callable[[str | None], tuple[tuple[int, int], ...]] = cyrillic_sort_key
