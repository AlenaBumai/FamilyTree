"""Локальный запуск приложения через Waitress."""

from __future__ import annotations

import errno
import logging
import sys
import threading
from collections.abc import Iterable
from typing import Any, TextIO

from flask import Flask
from waitress import create_server

from app.paths import DataPaths, get_data_paths
from app.web import create_app


HOST = "127.0.0.1"
FIRST_PORT = 8765
LAST_PORT = 8815


def configure_logging(paths: DataPaths) -> None:
    """Направить журналы приложения в каталог пользовательских данных."""

    paths.create()
    logging.basicConfig(
        filename=paths.root / "family-tree.log",
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
        encoding="utf-8",
        force=True,
    )


def _is_address_in_use(error: OSError) -> bool:
    return error.errno == errno.EADDRINUSE or getattr(error, "winerror", None) == 10048


def bind_server(application: Flask, ports: Iterable[int]) -> tuple[Any, int]:
    """Связать первый свободный порт без разрыва между проверкой и bind."""

    for port in ports:
        try:
            return create_server(application, host=HOST, port=port), port
        except OSError as error:
            if not _is_address_in_use(error):
                raise
    raise RuntimeError("Не найден свободный локальный порт для запуска приложения")


def _shutdown_waitress_server(server: Any) -> None:
    """Остановить приём запросов и закрыть соединения после отправки буферов."""

    logging.getLogger(__name__).info("Получена команда штатного завершения")
    active_channels = tuple(
        getattr(server, "active_channels", {}).values()
    )
    for channel in active_channels:
        channel.close_when_flushed = True
    try:
        server.close()
    finally:
        dispatcher = getattr(server, "task_dispatcher", None)
        if dispatcher is not None:
            dispatcher.shutdown()


def schedule_server_shutdown(server: Any) -> None:
    """Запустить завершение вне потока, который отдаёт последнюю страницу."""

    shutdown_thread = threading.Thread(
        target=_shutdown_waitress_server,
        args=(server,),
        name="family-tree-shutdown",
        daemon=False,
    )
    shutdown_thread.start()


def run_server(
    application: Flask,
    *,
    output: TextIO | None = None,
    ports: Iterable[int] = range(FIRST_PORT, LAST_PORT + 1),
) -> None:
    """Запустить сервер и выдать контрактную строку после успешного bind."""

    server, port = bind_server(application, ports)
    application.config["SERVER_SHUTDOWN"] = lambda: schedule_server_shutdown(server)
    ready_output = sys.stdout if output is None else output
    ready_output.write(f"FAMILY_TREE_READY http://{HOST}:{port}/\n")
    ready_output.flush()
    logging.getLogger(__name__).info("Сервер запущен на %s:%s", HOST, port)
    server.run()


def main() -> None:
    paths = get_data_paths()
    configure_logging(paths)
    application = create_app({"DATA_PATHS": paths})
    run_server(application)


if __name__ == "__main__":
    main()
