"""Локальные настройки интерфейса в каталоге пользовательских данных."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass

from app.paths import DataPaths


SETTINGS_FILENAME = "settings.json"
LIST_MODE_ALL = "all"
LIST_MODE_LIVING = "living"
LIST_MODES = {LIST_MODE_ALL, LIST_MODE_LIVING}


@dataclass(frozen=True)
class AppSettings:
    start_list_mode: str = LIST_MODE_ALL
    tree_root_id: int | None = None


def _read_settings_data(paths: DataPaths) -> dict[str, object]:
    try:
        raw = json.loads((paths.root / SETTINGS_FILENAME).read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        return {}
    return raw if isinstance(raw, dict) else {}


def load_settings(paths: DataPaths) -> AppSettings:
    """Прочитать независимые настройки; повреждённые значения заменить умолчаниями."""

    raw = _read_settings_data(paths)
    mode = raw.get("start_list_mode")
    root_id = raw.get("tree_root_id")
    return AppSettings(
        start_list_mode=(
            mode if isinstance(mode, str) and mode in LIST_MODES else LIST_MODE_ALL
        ),
        tree_root_id=root_id if type(root_id) is int and root_id > 0 else None,
    )


def save_settings(paths: DataPaths, settings: AppSettings) -> None:
    """Атомарно записать проверенные настройки рядом с базой."""

    if settings.start_list_mode not in LIST_MODES:
        raise ValueError("Неизвестный режим стартового списка")
    if settings.tree_root_id is not None and (
        type(settings.tree_root_id) is not int or settings.tree_root_id <= 0
    ):
        raise ValueError("Неверный идентификатор корня дерева")
    paths.create()
    settings_path = paths.root / SETTINGS_FILENAME
    temporary_path = paths.root / f".{SETTINGS_FILENAME}.tmp"
    content_data = _read_settings_data(paths)
    content_data.update(
        start_list_mode=settings.start_list_mode,
        tree_root_id=settings.tree_root_id,
    )
    content = json.dumps(
        content_data,
        ensure_ascii=False,
        indent=2,
    )
    temporary_path.write_text(f"{content}\n", encoding="utf-8")
    os.replace(temporary_path, settings_path)
