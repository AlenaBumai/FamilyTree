"""Репозиторий персон и родственных связей."""

from __future__ import annotations

import hashlib
import sqlite3
from collections.abc import Mapping
from datetime import date
from pathlib import Path
from typing import Any

from app.db import configure_connection, connect, migrate
from app.lifespan import (
    LIFE_STATUS_UNKNOWN,
    is_alive,
    normalize_life_status,
    normalize_year,
)
from app.textutil import norm, normalize_gender


PERSON_INPUT_FIELDS = (
    "p_surname",
    "p_surname_unmarried",
    "p_name",
    "p_fath_name",
    "surname_lat",
    "name_lat",
    "birth_date",
    "birth_date_is_estimated",
    "birth_year",
    "death_date",
    "death_date_is_estimated",
    "death_year",
    "life_status",
    "main_lane",
    "gender",
    "city_live",
    "city_buried",
    "photo",
    "info",
)
SEARCH_FIELDS = {
    "p_surname": "p_surname_lc",
    "p_surname_unmarried": "p_surname_unmarried_lc",
    "p_name": "p_name_lc",
    "p_fath_name": "p_fath_name_lc",
}
OPTIONAL_TEXT_FIELDS = {
    "p_surname_unmarried",
    "p_fath_name",
    "surname_lat",
    "name_lat",
    "city_live",
    "city_buried",
    "photo",
}
PARENT_ROLES = {"отец", "мать", "не указано"}
RELATION_TYPES = {"родной", "приёмный", "не указано"}
MAX_PARENTS = 2

_PERSON_COLUMNS = PERSON_INPUT_FIELDS + tuple(SEARCH_FIELDS.values())
_PERSON_COLUMN_SQL = ", ".join(_PERSON_COLUMNS)
_PERSON_PLACEHOLDERS = ", ".join("?" for _ in _PERSON_COLUMNS)
_PERSON_ORDER = """
ORDER BY p_surname_lc COLLATE CYRILLIC,
         p_name_lc COLLATE CYRILLIC,
         p_fath_name_lc COLLATE CYRILLIC,
         id_person
"""


class ConcurrentUpdateError(RuntimeError):
    """Запись изменилась после открытия формы редактирования."""


def _clean_name(value: Any, field_name: str) -> str:
    if not isinstance(value, str):
        raise ValueError(f"Поле {field_name} должно быть строкой")
    cleaned = " ".join(value.strip().split())
    if not cleaned:
        raise ValueError(f"Поле {field_name} обязательно")
    return cleaned


def _clean_optional_text(value: Any) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str):
        raise ValueError("Текстовое поле должно быть строкой")
    cleaned = value.strip()
    return cleaned or None


def _clean_date(value: Any, field_name: str) -> str | None:
    cleaned = _clean_optional_text(value)
    if cleaned is None:
        return None
    try:
        parsed = date.fromisoformat(cleaned)
    except ValueError as error:
        raise ValueError(f"Поле {field_name} должно содержать дату YYYY-MM-DD") from error
    if parsed.isoformat() != cleaned:
        raise ValueError(f"Поле {field_name} должно содержать дату YYYY-MM-DD")
    return cleaned


def _clean_year(value: Any, field_name: str) -> int | None:
    if value is None or value == "":
        return None
    if isinstance(value, bool):
        raise ValueError(f"Поле {field_name} должно содержать год")
    try:
        year = int(value)
    except (TypeError, ValueError) as error:
        raise ValueError(f"Поле {field_name} должно содержать год") from error
    return normalize_year(year)


def _clean_boolean(value: Any, field_name: str) -> int:
    if value in (True, 1, "1"):
        return 1
    if value in (False, 0, "0", None, ""):
        return 0
    raise ValueError(f"Поле {field_name} должно иметь значение 0 или 1")


def _prepare_person(values: Mapping[str, Any]) -> dict[str, Any]:
    unknown = set(values) - set(PERSON_INPUT_FIELDS)
    if unknown:
        raise ValueError(f"Неизвестные поля персоны: {', '.join(sorted(unknown))}")

    prepared: dict[str, Any] = {}
    prepared["p_surname"] = _clean_name(values.get("p_surname"), "Фамилия")
    prepared["p_name"] = _clean_name(values.get("p_name"), "Имя")

    for field_name in OPTIONAL_TEXT_FIELDS:
        prepared[field_name] = _clean_optional_text(values.get(field_name))

    info = values.get("info")
    if info is not None and not isinstance(info, str):
        raise ValueError("Поле Биография должно быть строкой")
    prepared["info"] = info if info not in (None, "") else None

    prepared["birth_date"] = _clean_date(values.get("birth_date"), "Дата рождения")
    prepared["death_date"] = _clean_date(values.get("death_date"), "Дата смерти")
    prepared["birth_year"] = _clean_year(values.get("birth_year"), "Год рождения")
    prepared["death_year"] = _clean_year(values.get("death_year"), "Год смерти")
    if prepared["birth_date"] is not None:
        prepared["birth_year"] = int(prepared["birth_date"][:4])
    if prepared["death_date"] is not None:
        prepared["death_year"] = int(prepared["death_date"][:4])

    prepared["birth_date_is_estimated"] = _clean_boolean(
        values.get("birth_date_is_estimated", 0), "Дата рождения предположительная"
    )
    prepared["death_date_is_estimated"] = _clean_boolean(
        values.get("death_date_is_estimated", 0), "Дата смерти предположительная"
    )
    prepared["main_lane"] = _clean_boolean(
        values.get("main_lane", 0), "Основная линия"
    )

    raw_life_status = values.get("life_status", LIFE_STATUS_UNKNOWN)
    if raw_life_status in (None, ""):
        raw_life_status = LIFE_STATUS_UNKNOWN
    prepared["life_status"] = normalize_life_status(raw_life_status)
    if prepared["life_status"] is None:
        raise ValueError(
            "Статус жизни должен иметь значение «жив», «умер» или «неизвестно»"
        )
    if is_alive(prepared["life_status"]) and (
        prepared["death_date"] is not None or prepared["death_year"] is not None
    ):
        raise ValueError(
            "Для статуса «жив» дата и год смерти должны быть пустыми"
        )

    gender = values.get("gender")
    if gender in (None, ""):
        prepared["gender"] = None
    elif isinstance(gender, str):
        prepared["gender"] = normalize_gender(gender)
    else:
        raise ValueError("Пол должен иметь значение «М» или «Ж»")
    if gender not in (None, "") and prepared["gender"] is None:
        raise ValueError("Пол должен иметь значение «М» или «Ж»")

    for source, target in SEARCH_FIELDS.items():
        prepared[target] = norm(prepared[source])
    return prepared


def _escape_like(value: str) -> str:
    return value.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")


def _as_dict(row: sqlite3.Row | None) -> dict[str, Any] | None:
    return None if row is None else dict(row)


def start_screen_filter_sql(living_only: bool) -> str:
    """Вернуть единое правило стартового экрана с выбранным режимом."""

    # Правило стартового экрана обсуждается с заказчицей и меняется только здесь.
    condition = "main_lane = 1"
    if living_only:
        return f"{condition} AND is_alive(life_status) = 1"
    return condition


class PersonRepository:
    """CRUD API над одной базой семейного дерева."""

    def __init__(self, database: str | Path | sqlite3.Connection) -> None:
        if isinstance(database, sqlite3.Connection):
            self.connection = configure_connection(database)
            self._owns_connection = False
        else:
            self.connection = connect(database)
            self._owns_connection = True
        migrate(self.connection)

    def __enter__(self) -> "PersonRepository":
        return self

    def __exit__(self, *_exc_info: object) -> None:
        self.close()

    def close(self) -> None:
        if self._owns_connection:
            self.connection.close()

    def create_person(self, values: Mapping[str, Any]) -> int:
        prepared = _prepare_person(values)
        parameters = tuple(prepared[column] for column in _PERSON_COLUMNS)
        with self.connection:
            cursor = self.connection.execute(
                f"INSERT INTO person ({_PERSON_COLUMN_SQL}) VALUES ({_PERSON_PLACEHOLDERS})",
                parameters,
            )
        return int(cursor.lastrowid)

    def get_person(self, person_id: int) -> dict[str, Any] | None:
        row = self.connection.execute(
            "SELECT * FROM person WHERE id_person = ?", (person_id,)
        ).fetchone()
        return _as_dict(row)

    def update_person(self, person_id: int, changes: Mapping[str, Any]) -> bool:
        current = self.get_person(person_id)
        if current is None:
            return False
        unknown = set(changes) - set(PERSON_INPUT_FIELDS)
        if unknown:
            raise ValueError(f"Неизвестные поля персоны: {', '.join(sorted(unknown))}")
        merged = {field: current[field] for field in PERSON_INPUT_FIELDS}
        merged.update(changes)
        prepared = _prepare_person(merged)
        assignments = ", ".join(f"{column} = ?" for column in _PERSON_COLUMNS)
        parameters = tuple(prepared[column] for column in _PERSON_COLUMNS) + (person_id,)
        with self.connection:
            self.connection.execute(
                f"UPDATE person SET {assignments} WHERE id_person = ?", parameters
            )
        return True

    def person_version(self, person_id: int) -> str | None:
        """Вернуть стабильный отпечаток пользовательских полей и связей."""

        person = self.get_person(person_id)
        if person is None:
            return None
        return self._person_version(person_id, person)

    def save_person_with_parents(
        self,
        values: Mapping[str, Any],
        parents: Mapping[int, str],
        *,
        person_id: int | None = None,
        expected_version: str | None = None,
        overwrite: bool = False,
    ) -> int:
        """Атомарно сохранить персону и выбранных родителей."""

        parent_choices = self._parent_choices(parents)
        if person_id is not None and person_id in parent_choices:
            raise ValueError("Человек не может быть родителем самому себе")

        self.connection.execute("BEGIN IMMEDIATE")
        try:
            if person_id is None:
                prepared = _prepare_person(values)
                parameters = tuple(prepared[column] for column in _PERSON_COLUMNS)
                cursor = self.connection.execute(
                    f"INSERT INTO person ({_PERSON_COLUMN_SQL}) "
                    f"VALUES ({_PERSON_PLACEHOLDERS})",
                    parameters,
                )
                saved_person_id = int(cursor.lastrowid)
            else:
                current = self.get_person(person_id)
                if current is None:
                    raise ValueError("Персона не найдена")
                current_version = self._person_version(person_id, current)
                if not overwrite and expected_version != current_version:
                    raise ConcurrentUpdateError(
                        "Запись изменилась после открытия формы"
                    )
                unknown = set(values) - set(PERSON_INPUT_FIELDS)
                if unknown:
                    raise ValueError(
                        f"Неизвестные поля персоны: {', '.join(sorted(unknown))}"
                    )
                merged = {field: current[field] for field in PERSON_INPUT_FIELDS}
                merged.update(values)
                prepared = _prepare_person(merged)
                assignments = ", ".join(
                    f"{column} = ?" for column in _PERSON_COLUMNS
                )
                parameters = tuple(
                    prepared[column] for column in _PERSON_COLUMNS
                ) + (person_id,)
                self.connection.execute(
                    f"UPDATE person SET {assignments} WHERE id_person = ?",
                    parameters,
                )
                saved_person_id = person_id

            self._replace_parents(saved_person_id, parent_choices)
            self.connection.commit()
        except BaseException:
            self.connection.rollback()
            raise
        return saved_person_id

    def delete_person(self, person_id: int) -> bool:
        with self.connection:
            cursor = self.connection.execute(
                "DELETE FROM person WHERE id_person = ?", (person_id,)
            )
        return cursor.rowcount > 0

    def list_people(self) -> list[dict[str, Any]]:
        rows = self.connection.execute(f"SELECT * FROM person {_PERSON_ORDER}").fetchall()
        return [dict(row) for row in rows]

    def list_relationships(self) -> list[dict[str, Any]]:
        """Вернуть связи в устойчивом порядке для выгрузки."""

        rows = self.connection.execute(
            "SELECT * FROM parent_child ORDER BY id"
        ).fetchall()
        return [dict(row) for row in rows]

    def repair_search_fields(self) -> int:
        """Восстановить рассогласованные производные поля поиска одним пакетом."""

        rows = self.connection.execute(
            """
            SELECT id_person,
                   p_surname, p_surname_unmarried, p_name, p_fath_name,
                   p_surname_lc, p_surname_unmarried_lc, p_name_lc, p_fath_name_lc
            FROM person
            """
        ).fetchall()
        repairs: list[tuple[str, str, str, str, int]] = []
        for row in rows:
            normalized = tuple(norm(row[source]) for source in SEARCH_FIELDS)
            stored = tuple(row[target] for target in SEARCH_FIELDS.values())
            if normalized != stored:
                repairs.append((*normalized, int(row["id_person"])))

        if repairs:
            with self.connection:
                self.connection.executemany(
                    """
                    UPDATE person
                    SET p_surname_lc = ?,
                        p_surname_unmarried_lc = ?,
                        p_name_lc = ?,
                        p_fath_name_lc = ?
                    WHERE id_person = ?
                    """,
                    repairs,
                )
        return len(repairs)

    def list_default(self, *, living_only: bool = False) -> list[dict[str, Any]]:
        filter_sql = start_screen_filter_sql(living_only)
        rows = self.connection.execute(
            f"SELECT * FROM person WHERE {filter_sql} {_PERSON_ORDER}"
        ).fetchall()
        return [dict(row) for row in rows]

    def search_people(
        self,
        surname: str | None = None,
        name: str | None = None,
        patronymic: str | None = None,
    ) -> list[dict[str, Any]]:
        criteria: list[str] = []
        parameters: list[str] = []

        normalized_surname = norm(surname)
        if normalized_surname:
            criteria.append(
                "(p_surname_lc LIKE (? || '%') ESCAPE '\\' "
                "OR p_surname_unmarried_lc LIKE (? || '%') ESCAPE '\\')"
            )
            escaped = _escape_like(normalized_surname)
            parameters.extend((escaped, escaped))

        for value, column in ((name, "p_name_lc"), (patronymic, "p_fath_name_lc")):
            normalized = norm(value)
            if normalized:
                criteria.append(f"{column} LIKE (? || '%') ESCAPE '\\'")
                parameters.append(_escape_like(normalized))

        if not criteria:
            raise ValueError("Укажите хотя бы один критерий поиска")
        where = " AND ".join(criteria)
        rows = self.connection.execute(
            f"SELECT * FROM person WHERE {where} {_PERSON_ORDER}", parameters
        ).fetchall()
        return [dict(row) for row in rows]

    def create_relationship(
        self,
        parent_id: int,
        child_id: int,
        parent_role: str | None = "не указано",
        relation_type: str | None = "не указано",
    ) -> int:
        role = self._parent_role(parent_role)
        relation = self._relation_type(relation_type)
        with self.connection:
            self._ensure_parent_capacity(child_id)
            cursor = self.connection.execute(
                """
                INSERT INTO parent_child
                    (id_parent, id_child, parent_role, relation_type)
                VALUES (?, ?, ?, ?)
                """,
                (parent_id, child_id, role, relation),
            )
        return int(cursor.lastrowid)

    def get_relationship(self, relationship_id: int) -> dict[str, Any] | None:
        row = self.connection.execute(
            "SELECT * FROM parent_child WHERE id = ?", (relationship_id,)
        ).fetchone()
        return _as_dict(row)

    def update_relationship(
        self,
        relationship_id: int,
        *,
        parent_id: int | None = None,
        child_id: int | None = None,
        parent_role: str | None = None,
        relation_type: str | None = None,
    ) -> bool:
        current = self.get_relationship(relationship_id)
        if current is None:
            return False
        target_child_id = current["id_child"] if child_id is None else child_id
        self._ensure_parent_capacity(
            target_child_id, exclude_relationship_id=relationship_id
        )
        values = (
            current["id_parent"] if parent_id is None else parent_id,
            current["id_child"] if child_id is None else child_id,
            current["parent_role"]
            if parent_role is None
            else self._parent_role(parent_role),
            current["relation_type"]
            if relation_type is None
            else self._relation_type(relation_type),
            relationship_id,
        )
        with self.connection:
            self.connection.execute(
                """
                UPDATE parent_child
                SET id_parent = ?, id_child = ?, parent_role = ?, relation_type = ?
                WHERE id = ?
                """,
                values,
            )
        return True

    def delete_relationship(self, relationship_id: int) -> bool:
        with self.connection:
            cursor = self.connection.execute(
                "DELETE FROM parent_child WHERE id = ?", (relationship_id,)
            )
        return cursor.rowcount > 0

    def get_parents(self, person_id: int) -> list[dict[str, Any]]:
        rows = self.connection.execute(
            f"""
            SELECT p.*, pc.id AS relationship_id, pc.parent_role, pc.relation_type
            FROM parent_child AS pc
            JOIN person AS p ON p.id_person = pc.id_parent
            WHERE pc.id_child = ?
            {_PERSON_ORDER}
            """,
            (person_id,),
        ).fetchall()
        return [dict(row) for row in rows]

    def get_children(self, person_id: int) -> list[dict[str, Any]]:
        rows = self.connection.execute(
            f"""
            SELECT p.*, pc.id AS relationship_id, pc.parent_role, pc.relation_type
            FROM parent_child AS pc
            JOIN person AS p ON p.id_person = pc.id_child
            WHERE pc.id_parent = ?
            {_PERSON_ORDER}
            """,
            (person_id,),
        ).fetchall()
        return [dict(row) for row in rows]

    def _ensure_parent_capacity(
        self,
        child_id: int,
        *,
        exclude_relationship_id: int | None = None,
    ) -> None:
        if exclude_relationship_id is None:
            row = self.connection.execute(
                "SELECT COUNT(*) AS count FROM parent_child WHERE id_child = ?",
                (child_id,),
            ).fetchone()
        else:
            row = self.connection.execute(
                """
                SELECT COUNT(*) AS count
                FROM parent_child
                WHERE id_child = ? AND id <> ?
                """,
                (child_id, exclude_relationship_id),
            ).fetchone()
        if row is not None and row["count"] >= MAX_PARENTS:
            raise ValueError("У персоны не может быть более двух родителей")

    def _person_version(
        self,
        person_id: int,
        person: Mapping[str, Any],
    ) -> str:
        relationships = self.connection.execute(
            """
            SELECT id_parent, parent_role, relation_type
            FROM parent_child
            WHERE id_child = ?
            ORDER BY id_parent, id
            """,
            (person_id,),
        ).fetchall()
        snapshot = (
            tuple(person[field] for field in PERSON_INPUT_FIELDS),
            tuple(
                (row["id_parent"], row["parent_role"], row["relation_type"])
                for row in relationships
            ),
        )
        return hashlib.sha256(repr(snapshot).encode("utf-8")).hexdigest()

    def _replace_parents(
        self,
        child_id: int,
        selected: Mapping[int, str],
    ) -> None:
        current_rows = self.connection.execute(
            """
            SELECT id, id_parent, parent_role
            FROM parent_child
            WHERE id_child = ?
            """,
            (child_id,),
        ).fetchall()
        current = {int(row["id_parent"]): row for row in current_rows}
        for parent_id, relationship in current.items():
            if parent_id not in selected:
                self.connection.execute(
                    "DELETE FROM parent_child WHERE id = ?",
                    (relationship["id"],),
                )
        for parent_id, role in selected.items():
            relationship = current.get(parent_id)
            if relationship is None:
                self.connection.execute(
                    """
                    INSERT INTO parent_child
                        (id_parent, id_child, parent_role, relation_type)
                    VALUES (?, ?, ?, ?)
                    """,
                    (parent_id, child_id, role, "не указано"),
                )
            elif relationship["parent_role"] != role:
                self.connection.execute(
                    "UPDATE parent_child SET parent_role = ? WHERE id = ?",
                    (role, relationship["id"]),
                )

    @classmethod
    def _parent_choices(cls, parents: Mapping[int, str]) -> dict[int, str]:
        if len(parents) > MAX_PARENTS:
            raise ValueError("У персоны не может быть более двух родителей")
        choices: dict[int, str] = {}
        for parent_id, role in parents.items():
            if isinstance(parent_id, bool) or not isinstance(parent_id, int):
                raise ValueError("Идентификатор родителя указан неверно")
            choices[parent_id] = cls._parent_role(role)
        return choices

    @staticmethod
    def _parent_role(value: str | None) -> str:
        normalized = "не указано" if value in (None, "") else value
        if normalized not in PARENT_ROLES:
            raise ValueError("Недопустимая роль родителя")
        return normalized

    @staticmethod
    def _relation_type(value: str | None) -> str:
        normalized = "не указано" if value in (None, "") else value
        if normalized not in RELATION_TYPES:
            raise ValueError("Недопустимый тип родства")
        return normalized


Repository = PersonRepository
