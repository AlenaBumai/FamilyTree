"""Чистое построение и размещение дерева предков."""

from __future__ import annotations

import re
from collections import defaultdict
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from typing import Any

from app.lifespan import normalize_year


CARD_WIDTH = 156
CARD_HEIGHT = 244
COLUMN_STEP = 174
ROW_GAP = 52
MARGIN = 18
NAME_BASELINE = 152
NAME_LINE_STEP = 20
MIN_YEAR_BASELINE = 220
YEAR_GAP = 28
CARD_BOTTOM_GAP = 20
MAX_NAME_LINE_CHARS = 18
MAX_GENERATION = 100


@dataclass(frozen=True)
class AncestorNode:
    person_id: int
    generation: int
    parents: tuple[AncestorNode, ...] = ()
    repeated: bool = False


@dataclass(frozen=True)
class PlacedNode:
    key: int
    person_id: int
    generation: int
    left: int
    top: int
    repeated: bool = False


@dataclass(frozen=True)
class PlacedLine:
    parent_id: int
    child_id: int
    x1: int
    y1: int
    x2: int
    y2: int


@dataclass(frozen=True)
class TreeLayout:
    nodes: tuple[PlacedNode, ...]
    lines: tuple[PlacedLine, ...]
    width: int
    height: int
    card_height: int


def split_name_lines(full_name: str) -> tuple[str, ...]:
    """Держать короткое прозвище рядом с именем внутри узкой карточки."""

    words = re.findall(r"\([^)]*\)|\S+", full_name)
    lines: list[str] = []
    for word in words:
        if (
            word.startswith("(")
            and lines
            and len(lines[-1]) + 1 + len(word) <= MAX_NAME_LINE_CHARS
        ):
            lines[-1] += f" {word}"
        else:
            lines.extend(
                word[start:start + MAX_NAME_LINE_CHARS]
                for start in range(0, len(word), MAX_NAME_LINE_CHARS)
            )
    return tuple(lines)


def caption_year_baseline(line_count: int) -> int:
    """Годы стоят после последней строки имени с постоянным зазором."""

    last_name_baseline = NAME_BASELINE + max(0, line_count - 1) * NAME_LINE_STEP
    return max(MIN_YEAR_BASELINE, last_name_baseline + YEAR_GAP)


def _parent_ids(
    people: Mapping[int, Mapping[str, Any]],
    relationships: Iterable[Mapping[str, Any]],
) -> dict[int, list[int]]:
    choices: dict[int, list[tuple[tuple[int, int], int]]] = defaultdict(list)
    for relationship in relationships:
        child_id = int(relationship["id_child"])
        parent_id = int(relationship["id_parent"])
        if child_id not in people or parent_id not in people:
            continue
        role = relationship.get("parent_role")
        gender = people[parent_id].get("gender")
        if role == "отец":
            order = 0
        elif role == "мать":
            order = 3
        else:
            order = 1 if gender == "М" else 2
        choices[child_id].append(((order, parent_id), parent_id))
    return {
        child_id: [parent_id for _, parent_id in sorted(parents)]
        for child_id, parents in choices.items()
    }


def choose_default_root(
    people: Mapping[int, Mapping[str, Any]],
    relationships: Iterable[Mapping[str, Any]],
) -> int | None:
    """Выбрать конечную персону основной линии по числу известных предков."""

    if not people:
        return None
    links = tuple(relationships)
    parent_ids = _parent_ids(people, links)
    has_children = {int(link["id_parent"]) for link in links}
    candidates = [
        person_id for person_id, person in people.items()
        if person.get("main_lane") == 1 and person_id not in has_children
    ]
    if not candidates:
        candidates = [person_id for person_id in people if person_id not in has_children]
    if not candidates:
        candidates = list(people)

    def ancestor_count(person_id: int) -> int:
        seen = {person_id}
        pending = [person_id]
        while pending:
            for parent_id in parent_ids.get(pending.pop(), ()):
                if parent_id not in seen:
                    seen.add(parent_id)
                    pending.append(parent_id)
        return len(seen) - 1

    return max(
        candidates,
        key=lambda person_id: (
            ancestor_count(person_id),
            normalize_year(people[person_id].get("birth_year")) or -1,
            -person_id,
        ),
    )


def build_ancestor_tree(
    root_id: int,
    people: Mapping[int, Mapping[str, Any]],
    relationships: Iterable[Mapping[str, Any]],
    *,
    max_generation: int = MAX_GENERATION,
) -> tuple[AncestorNode, bool]:
    """Обойти поколения слева направо, разворачивая родителей персоны один раз."""

    parent_ids = _parent_ids(people, relationships)
    truncated = False
    positions: list[tuple[int, int, frozenset[int]]] = [(root_id, 0, frozenset())]
    parent_positions: list[list[int]] = [[]]
    expanded: set[int] = set()
    repeated_positions: set[int] = set()

    position = 0
    while position < len(positions):
        person_id, generation, path = positions[position]
        if person_id in expanded:
            repeated_positions.add(position)
        else:
            expanded.add(person_id)
            available = [
                parent_id for parent_id in parent_ids.get(person_id, ())[:2]
                if parent_id not in path and parent_id != person_id
            ]
            if generation >= max_generation:
                truncated = truncated or bool(available)
            else:
                next_path = path | {person_id}
                for parent_id in available:
                    parent_positions[position].append(len(positions))
                    positions.append((parent_id, generation + 1, next_path))
                    parent_positions.append([])
        position += 1

    def assemble(position: int) -> AncestorNode:
        person_id, generation, _path = positions[position]
        return AncestorNode(
            person_id,
            generation,
            tuple(assemble(parent) for parent in parent_positions[position]),
            position in repeated_positions,
        )

    return assemble(0), truncated


def layout_tree(
    root: AncestorNode,
    *,
    caption_line_counts: Mapping[int, int] | None = None,
) -> TreeLayout:
    """Разместить листья в отдельных колонках, детей — под центром родителей."""

    nodes: list[PlacedNode] = []
    edges: list[tuple[PlacedNode, PlacedNode]] = []
    leaf_count = 0
    has_repeats = False

    def place(node: AncestorNode) -> PlacedNode:
        nonlocal leaf_count, has_repeats
        has_repeats = has_repeats or node.repeated
        parents = [place(parent) for parent in node.parents]
        if parents:
            left = (parents[0].left + parents[-1].left) // 2
        else:
            left = MARGIN + leaf_count * COLUMN_STEP
            leaf_count += 1
        positioned = PlacedNode(
            len(nodes), node.person_id, node.generation, left, 0, node.repeated
        )
        nodes.append(positioned)
        edges.extend((parent, positioned) for parent in parents)
        return positioned

    place(root)
    line_counts = caption_line_counts or {}
    longest_caption = max(line_counts.get(node.person_id, 1) for node in nodes)
    card_height = max(
        CARD_HEIGHT,
        caption_year_baseline(longest_caption)
        + (CARD_BOTTOM_GAP + NAME_LINE_STEP if has_repeats else CARD_BOTTOM_GAP),
    )
    row_step = card_height + ROW_GAP
    highest = max(node.generation for node in nodes)
    positioned_nodes = tuple(
        PlacedNode(node.key, node.person_id, node.generation, node.left,
                   MARGIN + (highest - node.generation) * row_step,
                   node.repeated)
        for node in nodes
    )
    by_key = {node.key: node for node in positioned_nodes}
    lines = tuple(
        PlacedLine(
            parent.person_id, child.person_id,
            by_key[parent.key].left + CARD_WIDTH // 2,
            by_key[parent.key].top + card_height,
            by_key[child.key].left + CARD_WIDTH // 2,
            by_key[child.key].top,
        )
        for parent, child in edges
    )
    width = max(node.left for node in positioned_nodes) + CARD_WIDTH + MARGIN
    height = MARGIN + highest * row_step + card_height + MARGIN
    return TreeLayout(positioned_nodes, lines, width, height, card_height)
