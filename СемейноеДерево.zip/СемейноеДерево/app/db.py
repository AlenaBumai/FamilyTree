"""Подключение к SQLite и миграция начальной схемы."""

from __future__ import annotations

import sqlite3
from pathlib import Path

from app.lifespan import is_alive
from app.textutil import cyrillic_compare


CYRILLIC_COLLATION = "CYRILLIC"

DDL = """
CREATE TABLE IF NOT EXISTS person (
    id_person INTEGER PRIMARY KEY AUTOINCREMENT,
    p_surname TEXT NOT NULL,
    p_surname_unmarried TEXT,
    p_name TEXT NOT NULL,
    p_fath_name TEXT,
    surname_lat TEXT,
    name_lat TEXT,
    birth_date TEXT,
    -- Булев признак приблизительности даты рождения.
    birth_date_is_estimated INTEGER NOT NULL DEFAULT 0
        CHECK (birth_date_is_estimated IN (0, 1)),
    birth_year INTEGER,
    death_date TEXT,
    -- Булев признак приблизительности даты смерти.
    death_date_is_estimated INTEGER NOT NULL DEFAULT 0
        CHECK (death_date_is_estimated IN (0, 1)),
    death_year INTEGER,
    life_status TEXT NOT NULL DEFAULT 'неизвестно'
        CHECK (life_status IN ('жив', 'умер', 'неизвестно')),
    -- Булево: основная линия, прямое родство.
    main_lane INTEGER NOT NULL DEFAULT 0 CHECK (main_lane IN (0, 1)),
    gender TEXT CHECK (gender IS NULL OR gender IN ('М', 'Ж')),
    city_live TEXT,
    city_buried TEXT,
    photo TEXT,
    info TEXT,
    -- Технические производные колонки для поиска; вручную их править не нужно.
    p_surname_lc TEXT,
    p_surname_unmarried_lc TEXT,
    p_name_lc TEXT,
    p_fath_name_lc TEXT
);

CREATE TABLE IF NOT EXISTS parent_child (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    id_parent INTEGER NOT NULL,
    id_child INTEGER NOT NULL,
    parent_role TEXT DEFAULT 'не указано'
        CHECK (parent_role IS NULL OR parent_role IN ('отец', 'мать', 'не указано')),
    relation_type TEXT DEFAULT 'не указано'
        CHECK (relation_type IS NULL OR relation_type IN ('родной', 'приёмный', 'не указано')),
    UNIQUE (id_parent, id_child),
    CHECK (id_parent <> id_child),
    FOREIGN KEY (id_parent) REFERENCES person(id_person) ON DELETE CASCADE,
    FOREIGN KEY (id_child) REFERENCES person(id_person) ON DELETE CASCADE
);

-- В будущем здесь может появиться person_photo; текущее поле person.photo сохраняется.
"""

_PERSON_COLUMN_MIGRATIONS = {
    "birth_date_is_estimated": """
        ALTER TABLE person ADD COLUMN birth_date_is_estimated INTEGER NOT NULL
        DEFAULT 0 CHECK (birth_date_is_estimated IN (0, 1))
    """,
    "death_date_is_estimated": """
        ALTER TABLE person ADD COLUMN death_date_is_estimated INTEGER NOT NULL
        DEFAULT 0 CHECK (death_date_is_estimated IN (0, 1))
    """,
    "life_status": """
        ALTER TABLE person ADD COLUMN life_status TEXT NOT NULL
        DEFAULT 'неизвестно'
        CHECK (life_status IN ('жив', 'умер', 'неизвестно'))
    """,
}


def configure_connection(connection: sqlite3.Connection) -> sqlite3.Connection:
    """Включить обязательные настройки каждого соединения."""

    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    connection.create_collation(CYRILLIC_COLLATION, cyrillic_compare)
    connection.create_function("is_alive", 1, is_alive, deterministic=True)
    return connection


def connect(database_path: str | Path) -> sqlite3.Connection:
    """Открыть настроенное соединение с базой."""

    connection = sqlite3.connect(str(database_path))
    return configure_connection(connection)


def migrate(connection: sqlite3.Connection) -> None:
    """Создать отсутствующие таблицы без изменения существующих данных."""

    connection.executescript(DDL)
    existing_columns = {
        str(row["name"]) for row in connection.execute("PRAGMA table_info(person)")
    }
    for column_name, statement in _PERSON_COLUMN_MIGRATIONS.items():
        if column_name not in existing_columns:
            connection.execute(statement)
    connection.commit()


def initialize_database(database_path: str | Path) -> sqlite3.Connection:
    """Открыть базу и применить идемпотентную начальную миграцию."""

    connection = connect(database_path)
    migrate(connection)
    return connection
