"use strict";

function connectDateAndYear(dateId, yearId) {
  const dateInput = document.getElementById(dateId);
  const yearInput = document.getElementById(yearId);
  if (!dateInput || !yearInput) return;

  const synchronize = () => {
    const hasDate = dateInput.value.length > 0;
    yearInput.readOnly = hasDate;
    if (hasDate) yearInput.value = dateInput.value.slice(0, 4);
  };

  dateInput.addEventListener("input", synchronize);
  synchronize();
}

connectDateAndYear("birth_date", "birth_year");
connectDateAndYear("death_date", "death_year");

const parentSelector = document.querySelector("[data-parent-selector]");
if (parentSelector) {
  const maximum = Number(parentSelector.dataset.maximum);
  const checkboxes = Array.from(
    parentSelector.querySelectorAll('input[name="parent_ids"]')
  );
  const message = parentSelector.querySelector("[data-parent-limit-message]");

  const updateParentLimit = () => {
    const selectedCount = checkboxes.filter((checkbox) => checkbox.checked).length;
    const limitReached = selectedCount >= maximum;
    checkboxes.forEach((checkbox) => {
      checkbox.disabled = limitReached && !checkbox.checked;
    });
    if (message) {
      message.textContent = limitReached
        ? "Выбрано максимальное количество родителей."
        : "";
    }
  };

  checkboxes.forEach((checkbox) => {
    checkbox.addEventListener("change", updateParentLimit);
  });
  updateParentLimit();
}
