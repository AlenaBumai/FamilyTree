"""Расчёт возраста и форматирование годов жизни."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date

from app.textutil import format_year_count, lived_verb, year_word


LIFE_STATUS_ALIVE = "жив"
LIFE_STATUS_DECEASED = "умер"
LIFE_STATUS_UNKNOWN = "неизвестно"
LIFE_STATUSES = (
    LIFE_STATUS_ALIVE,
    LIFE_STATUS_DECEASED,
    LIFE_STATUS_UNKNOWN,
)


@dataclass(frozen=True)
class LifespanResult:
    """Структурированный результат одной из четырёх вычислимых веток."""

    # Для диапазона years хранит верхнюю границу ради совместимости API ядра.
    years: int
    exact: bool
    living: bool
    gender: str | None = None
    minimum_years: int | None = None


def _parse_date(value: str | date | None) -> date | None:
    if value is None or value == "":
        return None
    if isinstance(value, date):
        return value
    return date.fromisoformat(value)


def normalize_year(value: object) -> int | None:
    """Интерпретировать положительное целое как год, остальное — как отсутствие."""

    if value is None or value == "":
        return None
    if isinstance(value, bool):
        return None
    if isinstance(value, float) and not value.is_integer():
        return None
    try:
        year = int(value)
    except (TypeError, ValueError, OverflowError):
        return None
    return year if year > 0 else None


def normalize_life_status(value: object) -> str | None:
    """Привести известный статус жизни к каноническому значению."""

    if not isinstance(value, str):
        return None
    normalized = value.strip().lower()
    return normalized if normalized in LIFE_STATUSES else None


def _calendar_years(start: date, end: date) -> int:
    before_anniversary = (end.month, end.day) < (start.month, start.day)
    return end.year - start.year - int(before_anniversary)


def _result(
    years: int,
    *,
    exact: bool,
    living: bool,
    gender: str | None,
) -> LifespanResult | None:
    if years < 0:
        return None
    return LifespanResult(years=years, exact=exact, living=living, gender=gender)


def _range_result(
    maximum_years: int,
    *,
    living: bool,
    gender: str | None,
) -> LifespanResult | None:
    if maximum_years < 0:
        return None
    return LifespanResult(
        years=maximum_years,
        exact=False,
        living=living,
        gender=gender,
        minimum_years=maximum_years - 1,
    )


def is_alive(life_status: object) -> bool:
    """Единый предикат: живой статус задаётся явно, а не выводится из дат."""

    return normalize_life_status(life_status) == LIFE_STATUS_ALIVE


def has_lifespan_conflict(
    birth_date: str | date | None = None,
    birth_year: int | str | None = None,
    death_date: str | date | None = None,
    death_year: int | str | None = None,
) -> bool:
    """Проверить, указана ли смерть раньше рождения."""

    parsed_birth_date = _parse_date(birth_date)
    parsed_death_date = _parse_date(death_date)
    parsed_birth_year = normalize_year(birth_year)
    parsed_death_year = normalize_year(death_year)
    if parsed_death_date is None and parsed_death_year is None:
        return False
    if parsed_birth_date is not None and parsed_death_date is not None:
        return parsed_death_date < parsed_birth_date
    effective_birth_year = (
        parsed_birth_date.year if parsed_birth_date is not None else parsed_birth_year
    )
    effective_death_year = (
        parsed_death_date.year if parsed_death_date is not None else parsed_death_year
    )
    return (
        effective_birth_year is not None
        and effective_death_year is not None
        and effective_death_year < effective_birth_year
    )


def calculate_lifespan(
    birth_date: str | date | None = None,
    birth_year: int | str | None = None,
    death_date: str | date | None = None,
    death_year: int | str | None = None,
    gender: str | None = None,
    life_status: str | None = None,
    today: date | None = None,
) -> LifespanResult | None:
    """Рассчитать точный возраст или диапазон по доступной точности дат."""

    parsed_birth_date = _parse_date(birth_date)
    parsed_death_date = _parse_date(death_date)
    parsed_birth_year = normalize_year(birth_year)
    parsed_death_year = normalize_year(death_year)
    normalized_status = normalize_life_status(life_status)

    if normalized_status == LIFE_STATUS_UNKNOWN or normalized_status is None:
        return None

    living = is_alive(normalized_status)
    if living and (parsed_death_date is not None or parsed_death_year is not None):
        return None

    if (
        normalized_status == LIFE_STATUS_DECEASED
        and parsed_birth_date is not None
        and parsed_death_date is not None
    ):
        return _result(
            _calendar_years(parsed_birth_date, parsed_death_date),
            exact=True,
            living=False,
            gender=gender,
        )

    effective_birth_year = (
        parsed_birth_date.year if parsed_birth_date is not None else parsed_birth_year
    )
    effective_death_year = (
        parsed_death_date.year if parsed_death_date is not None else parsed_death_year
    )
    if (
        normalized_status == LIFE_STATUS_DECEASED
        and effective_birth_year is not None
        and effective_death_year is not None
    ):
        return _range_result(
            effective_death_year - effective_birth_year,
            living=False,
            gender=gender,
        )

    if living and parsed_birth_date is not None:
        current_date = date.today() if today is None else today
        return _result(
            _calendar_years(parsed_birth_date, current_date),
            exact=True,
            living=True,
            gender=gender,
        )
    if living and parsed_birth_year is not None:
        current_date = date.today() if today is None else today
        return _range_result(
            current_date.year - parsed_birth_year,
            living=True,
            gender=gender,
        )
    return None


def format_lifespan(result: LifespanResult | None) -> str:
    """Собрать русскую фразу из структурированного результата."""

    if result is None or result.years < 0:
        return ""
    minimum_years = (
        result.years
        if result.exact
        else result.minimum_years
        if result.minimum_years is not None
        else result.years - 1
    )
    if minimum_years > result.years:
        return ""
    if minimum_years < 0 and result.years == 0:
        years = "менее года"
    elif minimum_years < 0:
        return ""
    elif minimum_years == result.years:
        years = format_year_count(result.years)
    else:
        years = f"{minimum_years}-{result.years} {year_word(result.years)}"
    if result.living:
        return f"сейчас {years}"
    verb = lived_verb(result.gender)
    return f"{verb} {years}" if verb is not None else years


def format_life_years(
    birth_year: int | str | None,
    death_year: int | str | None,
    *,
    birth_date_is_estimated: object = False,
    death_date_is_estimated: object = False,
    life_status: object = None,
) -> str:
    """Отформатировать диапазон годов для строки результата."""

    birth = normalize_year(birth_year)
    death = normalize_year(death_year)
    birth_text = format_temporal_value(birth, birth_date_is_estimated)
    death_text = format_temporal_value(death, death_date_is_estimated)
    if birth is not None and death is not None:
        return f"{birth_text}-{death_text}"
    if birth is not None:
        return f"род. {birth_text}"
    if death is not None:
        return f"?-{death_text}"
    if normalize_life_status(life_status) == LIFE_STATUS_DECEASED:
        return "умер, годы неизвестны"
    return ""


def format_temporal_value(value: object, estimated: object = False) -> str:
    """Единая точка оформления известного или предположительного года."""

    if value in (None, ""):
        return ""
    prefix = "ок. " if estimated in (True, 1, "1") else ""
    return f"{prefix}{value}"
