"""Русский веб-интерфейс локального семейного архива."""

from __future__ import annotations

import logging
from collections.abc import Mapping
from dataclasses import replace
from io import BytesIO
from pathlib import Path
from typing import Any

from flask import (
    Flask,
    abort,
    current_app,
    g,
    redirect,
    render_template,
    request,
    send_file,
    url_for,
)

from app.csvexport import (
    PEOPLE_FILENAME,
    RELATIONSHIPS_FILENAME,
    export_people_csv,
    export_relationships_csv,
)
from app.lifespan import (
    LIFE_STATUSES,
    calculate_lifespan,
    format_life_years,
    format_lifespan,
    format_temporal_value,
    has_lifespan_conflict,
    is_alive,
    normalize_life_status,
    normalize_year,
)
from app.paths import DataPaths, get_data_paths
from app.photos import (
    MAX_PHOTO_BYTES,
    PhotoValidationError,
    UnsafePhotoPathError,
    resolve_photo_path,
    save_photo,
    validate_jpeg,
)
from app.repo import (
    MAX_PARENTS,
    PARENT_ROLES,
    ConcurrentUpdateError,
    PersonRepository,
)
from app.settings import (
    LIST_MODE_LIVING,
    LIST_MODES,
    load_settings,
    save_settings,
)
from app.textutil import normalize_gender
from app.tree import (
    CARD_WIDTH,
    MAX_GENERATION,
    NAME_BASELINE,
    NAME_LINE_STEP,
    build_ancestor_tree,
    caption_year_baseline,
    choose_default_root,
    layout_tree,
    split_name_lines,
)


FORM_FIELDS = (
    "p_surname",
    "p_surname_unmarried",
    "p_name",
    "p_fath_name",
    "surname_lat",
    "name_lat",
    "birth_date",
    "birth_date_is_estimated",
    "birth_year",
    "death_date",
    "death_date_is_estimated",
    "death_year",
    "life_status",
    "gender",
    "city_live",
    "city_buried",
    "info",
)
REQUIRED_FIELD_ERRORS = {
    "p_surname": "Введите фамилию.",
    "p_name": "Введите имя.",
    "gender": "Выберите пол: М или Ж.",
    "life_status": "Выберите статус жизни.",
}


def _data_paths() -> DataPaths:
    paths = current_app.config["DATA_PATHS"]
    if not isinstance(paths, DataPaths):
        raise RuntimeError("Каталог данных приложения настроен неверно")
    return paths


def _repository() -> PersonRepository:
    repository = g.get("person_repository")
    if repository is None:
        repository = PersonRepository(_data_paths().database)
        g.person_repository = repository
    return repository


def _close_repository(_error: BaseException | None = None) -> None:
    repository = g.pop("person_repository", None)
    if repository is not None:
        repository.close()


def _joined_name(person: Mapping[str, Any]) -> str:
    return " ".join(
        str(person[field]).strip()
        for field in ("p_surname", "p_name", "p_fath_name")
        if person.get(field)
    )


def _latin_name(person: Mapping[str, Any]) -> str:
    return " ".join(
        str(person[field]).strip()
        for field in ("surname_lat", "name_lat")
        if person.get(field)
    )


def format_person_summary(person: Mapping[str, Any]) -> str:
    """Собрать строку результата в порядке, заданном разделом 7.2."""

    full_name = _joined_name(person)
    latin_name = _latin_name(person)
    if latin_name:
        full_name = f"{full_name} ({latin_name})"
    parts = [full_name]
    years = format_life_years(
        person.get("birth_year"),
        person.get("death_year"),
        birth_date_is_estimated=person.get("birth_date_is_estimated"),
        death_date_is_estimated=person.get("death_date_is_estimated"),
        life_status=person.get("life_status"),
    )
    if years:
        parts.append(years)
    lifespan = calculate_lifespan(
        birth_date=person.get("birth_date"),
        birth_year=person.get("birth_year"),
        death_date=person.get("death_date"),
        death_year=person.get("death_year"),
        gender=person.get("gender"),
        life_status=person.get("life_status"),
    )
    lifespan_text = format_lifespan(lifespan)
    if lifespan_text:
        parts.append(lifespan_text)
    return ", ".join(parts)


def _media_exists(paths: DataPaths, relative_path: str | None) -> bool:
    if not relative_path:
        return False
    try:
        resolve_photo_path(paths, relative_path)
    except (FileNotFoundError, OSError, UnsafePhotoPathError):
        return False
    return True


def _person_view(person: Mapping[str, Any], paths: DataPaths) -> dict[str, Any]:
    view = dict(person)
    view["full_name"] = _joined_name(person)
    view["latin_name"] = _latin_name(person)
    view["summary"] = format_person_summary(person)
    view["life_years"] = format_life_years(
        person.get("birth_year"),
        person.get("death_year"),
        birth_date_is_estimated=person.get("birth_date_is_estimated"),
        death_date_is_estimated=person.get("death_date_is_estimated"),
        life_status=person.get("life_status"),
    )
    view["lifespan"] = format_lifespan(
        calculate_lifespan(
            birth_date=person.get("birth_date"),
            birth_year=person.get("birth_year"),
            death_date=person.get("death_date"),
            death_year=person.get("death_year"),
            gender=person.get("gender"),
            life_status=person.get("life_status"),
        )
    )
    view["is_alive"] = is_alive(person.get("life_status"))
    original_path = person.get("photo")
    view["photo_url"] = (
        url_for("media_file", relative_path=original_path)
        if _media_exists(paths, original_path)
        else url_for("static", filename="no-photo.svg")
    )
    thumbnail_path = f"thumbs/{person['id_person']}.jpg"
    view["thumbnail_url"] = (
        url_for("media_file", relative_path=thumbnail_path)
        if _media_exists(paths, thumbnail_path)
        else url_for("static", filename="no-photo.svg")
    )
    view["has_photo"] = _media_exists(paths, original_path)
    return view


def _detail_fields(person: Mapping[str, Any]) -> list[tuple[str, Any]]:
    gender = {"М": "мужской", "Ж": "женский"}.get(
        normalize_gender(person.get("gender")), "—"
    )
    life_status = normalize_life_status(person.get("life_status")) or "неизвестно"
    return [
        ("Идентификатор", person.get("id_person")),
        ("Фамилия", person.get("p_surname")),
        ("Девичья фамилия", person.get("p_surname_unmarried")),
        ("Имя", person.get("p_name")),
        ("Отчество", person.get("p_fath_name")),
        ("Фамилия латиницей", person.get("surname_lat")),
        ("Имя латиницей", person.get("name_lat")),
        (
            "Дата рождения",
            format_temporal_value(
                person.get("birth_date"), person.get("birth_date_is_estimated")
            ),
        ),
        (
            "Дата рождения предположительная",
            "да" if person.get("birth_date_is_estimated") else "нет",
        ),
        ("Год рождения", _stored_year_display(person.get("birth_year"))),
        (
            "Дата смерти",
            format_temporal_value(
                person.get("death_date"), person.get("death_date_is_estimated")
            ),
        ),
        (
            "Дата смерти предположительная",
            "да" if person.get("death_date_is_estimated") else "нет",
        ),
        ("Год смерти", _stored_year_display(person.get("death_year"))),
        ("Статус жизни", life_status),
        ("Основная линия", "да" if person.get("main_lane") else "нет"),
        ("Пол", gender),
        ("Город проживания", person.get("city_live")),
        ("Город захоронения", person.get("city_buried")),
        ("Фотография", "добавлена" if person.get("photo") else "—"),
        ("Биография и известные факты", person.get("info")),
    ]


def _stored_year_display(value: object) -> object:
    """Показать исходный маркер, не выдавая его за календарный год."""

    if value in (None, "") or normalize_year(value) is not None:
        return value
    return f"не указан (в данных: {value})"


def _unknown_year_markers(values: Mapping[str, Any]) -> dict[str, object | None]:
    """Найти сохранённые маркеры неизвестного года для пояснения в форме."""

    markers: dict[str, object | None] = {}
    for field_name in ("birth_year", "death_year"):
        value = values.get(field_name)
        markers[field_name] = (
            value
            if value not in (None, "") and normalize_year(value) is None
            else None
        )
    return markers


def _form_values(person: Mapping[str, Any] | None = None) -> dict[str, Any]:
    if request.method == "POST":
        values = {field: request.form.get(field, "") for field in FORM_FIELDS}
        raw_gender = values["gender"]
        values["gender"] = normalize_gender(raw_gender) or raw_gender.strip()
        raw_life_status = values["life_status"]
        values["life_status"] = (
            normalize_life_status(raw_life_status) or raw_life_status.strip().lower()
        )
        values["birth_date_is_estimated"] = (
            1 if request.form.get("birth_date_is_estimated") == "1" else 0
        )
        values["death_date_is_estimated"] = (
            1 if request.form.get("death_date_is_estimated") == "1" else 0
        )
        values["main_lane"] = 1 if request.form.get("main_lane") == "1" else 0
        return values
    if person is None:
        return {field: "" for field in FORM_FIELDS} | {"main_lane": 0}
    values = {
        field: person.get(field) if person.get(field) is not None else ""
        for field in FORM_FIELDS
    } | {
        "main_lane": person.get("main_lane", 0)
    }
    values["gender"] = normalize_gender(values["gender"]) or values["gender"]
    return values


def _validate_required_form_fields(values: Mapping[str, Any]) -> dict[str, str]:
    """Проверить обязательные поля именно пользовательской формы."""

    errors: dict[str, str] = {}
    for field_name in ("p_surname", "p_name"):
        value = values.get(field_name)
        if not isinstance(value, str) or not value.strip():
            errors[field_name] = REQUIRED_FIELD_ERRORS[field_name]
    if values.get("gender") not in ("М", "Ж"):
        errors["gender"] = REQUIRED_FIELD_ERRORS["gender"]
    if values.get("life_status") not in LIFE_STATUSES:
        errors["life_status"] = REQUIRED_FIELD_ERRORS["life_status"]
    elif is_alive(values.get("life_status")) and (
        values.get("death_date") not in (None, "")
        or normalize_year(values.get("death_year")) is not None
    ):
        errors["life_status"] = (
            "Статус «жив» противоречит заполненной дате или году смерти."
        )
    return errors


def _photo_upload() -> tuple[str, bytes] | None:
    uploaded = request.files.get("photo_file")
    if uploaded is None or not uploaded.filename:
        return None
    content = uploaded.stream.read(MAX_PHOTO_BYTES + 1)
    validate_jpeg(uploaded.filename, content)
    return uploaded.filename, content


def _role_for_gender(gender: str | None) -> str:
    return {"М": "отец", "Ж": "мать"}.get(
        normalize_gender(gender), "не указано"
    )


def _existing_parent_choices(
    repository: PersonRepository, person_id: int | None
) -> dict[int, str]:
    if person_id is None:
        return {}
    return {
        int(parent["id_person"]): str(parent["parent_role"])
        for parent in repository.get_parents(person_id)
    }


def _submitted_parent_choices(
    repository: PersonRepository, person_id: int | None
) -> tuple[dict[int, str], str | None]:
    raw_parent_ids = request.form.getlist("parent_ids")
    choices: dict[int, str] = {}
    error: str | None = None
    if len(raw_parent_ids) > MAX_PARENTS:
        error = "Можно выбрать не более двух родителей"

    for raw_parent_id in raw_parent_ids:
        try:
            parent_id = int(raw_parent_id)
        except ValueError:
            error = error or "Выбранный родитель указан неверно"
            continue
        if parent_id in choices:
            error = error or "Один человек не может быть выбран родителем дважды"
            continue
        if person_id is not None and parent_id == person_id:
            error = error or "Человек не может быть родителем самому себе"
            continue
        parent = repository.get_person(parent_id)
        if parent is None:
            error = error or "Выбранный родитель не найден"
            continue
        role = request.form.get(
            f"parent_role_{parent_id}", _role_for_gender(parent.get("gender"))
        )
        if role not in PARENT_ROLES:
            error = error or "Недопустимая роль родителя"
            continue
        choices[parent_id] = role
    return choices, error


def _parent_options(
    repository: PersonRepository,
    person_id: int | None,
    selected: Mapping[int, str],
) -> list[dict[str, Any]]:
    options: list[dict[str, Any]] = []
    for candidate in repository.list_people():
        candidate_id = int(candidate["id_person"])
        if candidate_id == person_id:
            continue
        default_role = _role_for_gender(candidate.get("gender"))
        options.append(
            {
                "id_person": candidate_id,
                "full_name": _joined_name(candidate),
                "life_years": format_life_years(
                    candidate.get("birth_year"),
                    candidate.get("death_year"),
                    birth_date_is_estimated=candidate.get(
                        "birth_date_is_estimated"
                    ),
                    death_date_is_estimated=candidate.get(
                        "death_date_is_estimated"
                    ),
                    life_status=candidate.get("life_status"),
                )
                or "годы жизни не указаны",
                "selected": candidate_id in selected,
                "selected_role": selected.get(candidate_id, default_role),
                "default_role": default_role,
            }
        )
    return options


def _has_date_warning(values: Mapping[str, Any]) -> bool:
    try:
        return has_lifespan_conflict(
            birth_date=values.get("birth_date"),
            birth_year=values.get("birth_year"),
            death_date=values.get("death_date"),
            death_year=values.get("death_year"),
        )
    except (TypeError, ValueError):
        return False


def create_app(config: Mapping[str, Any] | None = None) -> Flask:
    """Создать настроенное Flask-приложение без внешних сетевых зависимостей."""

    application = Flask(__name__)
    application.config.from_mapping(
        MAX_CONTENT_LENGTH=MAX_PHOTO_BYTES + 2 * 1024 * 1024,
    )
    if config:
        application.config.update(config)
    if "DATA_PATHS" not in application.config:
        application.config["DATA_PATHS"] = get_data_paths()
    paths = application.config["DATA_PATHS"]
    if not isinstance(paths, DataPaths):
        raise TypeError("DATA_PATHS должен иметь тип DataPaths")
    paths.create()
    application.config["START_LIST_MODE"] = load_settings(paths).start_list_mode
    with PersonRepository(paths.database) as repository:
        repaired_search_rows = repository.repair_search_fields()
    if repaired_search_rows:
        application.logger.info(
            "Исправлены служебные поисковые колонки: %d",
            repaired_search_rows,
        )

    application.teardown_appcontext(_close_repository)

    @application.after_request
    def add_local_security_headers(response: Any) -> Any:
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; img-src 'self'; style-src 'self'; "
            "script-src 'self'; object-src 'none'; base-uri 'self'"
        )
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Referrer-Policy"] = "no-referrer"
        return response

    def render_search(
        people: list[dict[str, Any]],
        *,
        searched: bool,
        criteria: Mapping[str, str] | None = None,
        error: str | None = None,
    ) -> str:
        views = [_person_view(person, paths) for person in people]
        return render_template(
            "search.html",
            people=views,
            searched=searched,
            criteria=criteria or {"surname": "", "name": "", "patronymic": ""},
            error=error,
            list_mode=application.config["START_LIST_MODE"],
        )

    @application.get("/")
    def index() -> str:
        mode = application.config["START_LIST_MODE"]
        return render_search(
            _repository().list_default(living_only=mode == LIST_MODE_LIVING),
            searched=False,
        )

    @application.post("/start-list-mode")
    def update_start_list_mode() -> Any:
        mode = request.form.get("mode", "")
        if mode not in LIST_MODES:
            abort(400)
        try:
            save_settings(paths, replace(load_settings(paths), start_list_mode=mode))
        except OSError:
            current_app.logger.exception("Не удалось сохранить настройку списка")
            return (
                render_template(
                    "error.html",
                    title="Не удалось сохранить настройку",
                    message="Проверьте доступность каталога данных и повторите попытку.",
                ),
                500,
            )
        application.config["START_LIST_MODE"] = mode
        return redirect(url_for("index"))

    @application.get("/search")
    def search() -> str:
        criteria = {
            "surname": request.args.get("surname", ""),
            "name": request.args.get("name", ""),
            "patronymic": request.args.get("patronymic", ""),
        }
        try:
            people = _repository().search_people(**criteria)
        except ValueError as error:
            return render_search([], searched=True, criteria=criteria, error=str(error))
        return render_search(people, searched=True, criteria=criteria)

    @application.get("/tree")
    def tree_page() -> str:
        people = _repository().list_people()
        by_id = {int(person["id_person"]): person for person in people}
        relationships = _repository().list_relationships()
        saved_root = load_settings(paths).tree_root_id
        root_id = saved_root if saved_root in by_id else choose_default_root(
            by_id, relationships
        )
        if root_id is None:
            return render_template("tree.html", root_id=None, options=[], cards=[], lines=[])

        ancestor_tree, truncated = build_ancestor_tree(root_id, by_id, relationships)
        name_lines = {
            person_id: split_name_lines(_joined_name(person))
            for person_id, person in by_id.items()
        }
        layout = layout_tree(
            ancestor_tree,
            caption_line_counts={
                person_id: len(lines) for person_id, lines in name_lines.items()
            },
        )
        tree_people = {
            node.person_id: _person_view(by_id[node.person_id], paths)
            for node in layout.nodes
        }
        cards = []
        for node in layout.nodes:
            person = tree_people[node.person_id]
            cards.append({
                "node": node,
                "person": person,
                "name_lines": name_lines[node.person_id],
                "years_y": caption_year_baseline(len(name_lines[node.person_id])),
                "image_url": (
                    person["thumbnail_url"]
                    if _media_exists(paths, f"thumbs/{node.person_id}.jpg")
                    else person["photo_url"]
                ),
            })
        options = [
            {
                "id_person": person["id_person"],
                "label": ", ".join(filter(None, (
                    _joined_name(person),
                    format_life_years(
                        person.get("birth_year"), person.get("death_year"),
                        birth_date_is_estimated=person.get("birth_date_is_estimated"),
                        death_date_is_estimated=person.get("death_date_is_estimated"),
                        life_status=person.get("life_status"),
                    ),
                ))),
            }
            for person in people
        ]
        return render_template(
            "tree.html", root_id=root_id, options=options, cards=cards,
            lines=layout.lines, width=layout.width, height=layout.height,
            card_width=CARD_WIDTH, card_center=CARD_WIDTH // 2,
            card_height=layout.card_height, name_baseline=NAME_BASELINE,
            name_line_step=NAME_LINE_STEP,
            repeat_note_y=layout.card_height - 12,
            max_generation=MAX_GENERATION, truncated=truncated,
        )

    @application.post("/tree/root")
    def choose_tree_root() -> Any:
        raw_id = request.form.get("person_id", "")
        try:
            person_id = int(raw_id)
            person = _repository().get_person(person_id) if person_id > 0 else None
        except (ValueError, OverflowError):
            person = None
        if person is None:
            return (
                render_template(
                    "error.html", title="Персона не найдена",
                    message="Выберите человека из списка на странице дерева.",
                    back_url=url_for("tree_page"), back_label="Вернуться к дереву",
                ),
                400,
            )
        try:
            save_settings(paths, replace(load_settings(paths), tree_root_id=person_id))
        except OSError:
            current_app.logger.exception("Не удалось сохранить корень дерева")
            return (
                render_template(
                    "error.html", title="Не удалось сохранить выбор",
                    message="Проверьте доступность каталога данных и повторите попытку.",
                ),
                500,
            )
        return redirect(url_for("tree_page"))

    @application.get("/export")
    def export_data() -> str:
        return render_template("export.html")

    @application.get("/export/people.csv")
    def export_people() -> Any:
        return send_file(
            BytesIO(export_people_csv(_repository())),
            mimetype="text/csv",
            as_attachment=True,
            download_name=PEOPLE_FILENAME,
        )

    @application.get("/export/relationships.csv")
    def export_relationships() -> Any:
        return send_file(
            BytesIO(export_relationships_csv(_repository())),
            mimetype="text/csv",
            as_attachment=True,
            download_name=RELATIONSHIPS_FILENAME,
        )

    @application.get("/person/<int:person_id>")
    def person_card(person_id: int) -> str:
        person = _repository().get_person(person_id)
        if person is None:
            abort(404)
        parents = [
            _person_view(relative, paths)
            for relative in _repository().get_parents(person_id)
        ]
        children = [
            _person_view(relative, paths)
            for relative in _repository().get_children(person_id)
        ]
        return render_template(
            "person.html",
            person=_person_view(person, paths),
            details=_detail_fields(person),
            parents=parents,
            children=children,
        )

    @application.route("/exit", methods=["GET", "POST"])
    def exit_application() -> Any:
        if request.method == "GET":
            return render_template("shutdown.html", shutdown_complete=False)

        response = application.make_response(
            render_template("shutdown.html", shutdown_complete=True)
        )
        response.headers["Cache-Control"] = "no-store"
        shutdown_callback = application.config.get("SERVER_SHUTDOWN")
        if callable(shutdown_callback):
            response.call_on_close(shutdown_callback)
        else:
            current_app.logger.error("Механизм завершения сервера не настроен")
        return response

    @application.route(
        "/person/new", methods=["GET", "POST"], defaults={"person_id": None}
    )
    @application.route("/person/<int:person_id>/edit", methods=["GET", "POST"])
    def person_form(person_id: int | None) -> str:
        repository = _repository()
        existing = repository.get_person(person_id) if person_id is not None else None
        if person_id is not None and existing is None:
            abort(404)
        values = _form_values(existing)
        if person_id is None:
            record_version = ""
        elif request.method == "POST":
            record_version = request.form.get("record_version", "")
        else:
            record_version = repository.person_version(person_id) or ""
        overwrite = request.form.get("force_save") == "1"
        concurrency_warning = False
        if request.method == "POST":
            parent_choices, parent_error = _submitted_parent_choices(
                repository, person_id
            )
            field_errors = _validate_required_form_fields(values)
        else:
            parent_choices = _existing_parent_choices(repository, person_id)
            parent_error = None
            field_errors = {}
        error_message: str | None = None

        if request.method == "POST" and parent_error is None and not field_errors:
            try:
                photo_upload = _photo_upload()
                saved_person_id = repository.save_person_with_parents(
                    values,
                    parent_choices,
                    person_id=person_id,
                    expected_version=record_version or None,
                    overwrite=overwrite,
                )

                if photo_upload is not None:
                    filename, content = photo_upload
                    photo_result = save_photo(paths, saved_person_id, filename, content)
                    repository.update_person(
                        saved_person_id, {"photo": photo_result.relative_path}
                    )
                    if not photo_result.thumbnail_created:
                        current_app.logger.warning(
                            "Не удалось создать миниатюру для персоны %s: %s",
                            saved_person_id,
                            photo_result.thumbnail_error,
                        )
                return redirect(url_for("person_card", person_id=saved_person_id))
            except ConcurrentUpdateError:
                concurrency_warning = True
            except (PhotoValidationError, ValueError) as error:
                error_message = str(error)
            except OSError:
                current_app.logger.exception("Не удалось сохранить фотографию")
                error_message = "Не удалось сохранить фотографию. Проверьте каталог данных."
        elif parent_error is not None:
            error_message = parent_error

        existing_view = _person_view(existing, paths) if existing is not None else None
        return render_template(
            "person_form.html",
            is_edit=person_id is not None,
            person=existing_view,
            values=values,
            error=error_message,
            concurrency_warning=concurrency_warning,
            record_version=record_version,
            field_errors=field_errors,
            date_warning=person_id is not None and _has_date_warning(values),
            unknown_year_markers=_unknown_year_markers(values),
            parent_options=_parent_options(
                repository, person_id, parent_choices
            ),
            parent_roles=("отец", "мать", "не указано"),
        )

    @application.get("/media/<path:relative_path>")
    def media_file(relative_path: str) -> Any:
        try:
            file_path = resolve_photo_path(paths, relative_path)
        except (FileNotFoundError, OSError, UnsafePhotoPathError):
            abort(404)
        return send_file(file_path, mimetype="image/jpeg", conditional=True)

    @application.errorhandler(404)
    def not_found(_error: Any) -> tuple[str, int]:
        return (
            render_template(
                "error.html",
                title="Страница не найдена",
                message="Запрошенная страница или фотография не найдена.",
            ),
            404,
        )

    @application.errorhandler(400)
    def invalid_request(_error: Any) -> tuple[str, int]:
        return (
            render_template(
                "error.html",
                title="Некорректный запрос",
                message="Не удалось применить выбранную настройку.",
            ),
            400,
        )

    @application.errorhandler(413)
    def request_too_large(_error: Any) -> tuple[str, int]:
        return (
            render_template(
                "error.html",
                title="Файл слишком большой",
                message="Размер фотографии не должен превышать 10 МБ.",
            ),
            413,
        )

    logging.getLogger("werkzeug").setLevel(logging.WARNING)
    return application
