"""Точка входа для запуска ``python -m app``."""

from app.server import main


main()

