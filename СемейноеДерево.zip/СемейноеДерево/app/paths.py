"""Разрешение и создание каталогов пользовательских данных."""

from __future__ import annotations

import os
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path


DATA_DIR_ENV = "FAMILY_TREE_DATA_DIR"


@dataclass(frozen=True)
class DataPaths:
    """Все пути, в которых приложение хранит пользовательские данные."""

    root: Path
    database: Path
    photos: Path
    thumbs: Path

    def create(self) -> "DataPaths":
        self.root.mkdir(parents=True, exist_ok=True)
        self.photos.mkdir(parents=True, exist_ok=True)
        self.thumbs.mkdir(parents=True, exist_ok=True)
        return self


def program_root() -> Path:
    """Вернуть корень программы для исходной и упакованной раскладки."""

    return Path(__file__).resolve().parent.parent


def resolve_data_dir(
    root: str | Path | None = None,
    environ: Mapping[str, str] | None = None,
) -> Path:
    """Разрешить каталог данных по переменной окружения или корню программы."""

    environment = os.environ if environ is None else environ
    configured = environment.get(DATA_DIR_ENV)
    if configured:
        return Path(configured).expanduser().resolve()
    base = program_root() if root is None else Path(root)
    return (base / "data").resolve()


def get_data_paths(
    root: str | Path | None = None,
    environ: Mapping[str, str] | None = None,
    *,
    create: bool = True,
) -> DataPaths:
    """Вернуть согласованный набор путей и при необходимости создать каталоги."""

    data_dir = resolve_data_dir(root, environ)
    paths = DataPaths(
        root=data_dir,
        database=data_dir / "family.db",
        photos=data_dir / "photos",
        thumbs=data_dir / "thumbs",
    )
    return paths.create() if create else paths

